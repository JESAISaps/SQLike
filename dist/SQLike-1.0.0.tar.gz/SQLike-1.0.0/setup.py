import setuptools

setuptools.setup(     
     name="SQLike",     
     version="1.0.0",
     )